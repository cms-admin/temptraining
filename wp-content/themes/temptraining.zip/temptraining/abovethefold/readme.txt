-------------------------------
  Above The Fold Optimization
-------------------------------

This directory contains theme related files for the plugin Above The Fold Optimization.

More information: https://wordpress.org/plugins/above-the-fold-optimization/