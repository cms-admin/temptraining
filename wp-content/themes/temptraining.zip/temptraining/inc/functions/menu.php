<?php
register_nav_menus( array(
  'primary'           => __( 'Основное меню', 'temptraining' ),
  'footer_menu_left'  => __( 'Футер-Меню слева', 'temptraining' ),
  'footer_menu_right' => __( 'Футер-Меню справа', 'temptraining' ),
  'category_menu_top' => __( 'Меню категорий вверху', 'temptraining' ),
  'contacts_menu' => __( 'Итоги в контактах', 'temptraining' ),
));
?>
