<?php

get_header();

the_content();

get_footer();

/*
<script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/js/jstree.js"></script>
<script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/js/dash.js"></script>
*/
?>
