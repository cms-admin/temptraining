<div class="sidebar-content row">
  <?php if ( is_active_sidebar( 'right_sidebar' ) ) : ?>
		<?php dynamic_sidebar( 'right_sidebar' ); ?>
	<?php endif; ?>
</div>
