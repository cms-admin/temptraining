<div class="plans-screen plans-finish fixed-bg">
  <h3 class="plans-finish__title"><?php echo $widget->title; ?></h3>
  <figure class="triangle-up-left"></figure>
  <div class="container">
    <div class="plans-finish__list">
      <?php echo $widget->text; ?>
      <button type="button" class="plans-finish__button" rel="Триатлон" data-toggle="modal" data-target="#begin-modal">Начать тренироваться</button>
    </div>
  </div>
  <figure class="triangle-down-right"></figure>
</div>
