<?php
/**
 * The template for displaying Category pages.
 *
 * Used to display archive-type pages for posts in a category.
 *
 * Learn more: http://codex.wordpress.org/Template_Hierarchy
 *
 * @package WordPress
 * @subpackage Twenty_Twelve
 * @since Twenty Twelve 1.0
 */

$t = 0;

get_header(); ?>

	<section id="primary" class="site-content">
		<div id="content" role="main">

		<?php
			$args = array(
				'type'                     => 'post',
				'child_of'                 => 0,
				'parent'                   => '',
				'orderby'                  => 'name',
				'order'                    => 'DESC',
				'hide_empty'               => 0,
				'hierarchical'             => 1,
				'exclude'                  => '1',
				'include'                  => '',
				'number'                   => '',
				'taxonomy'                 => 'category',
				'pad_counts'               => false
			);
	
			$categories_array = get_categories( $args );
			
			echo '<div class="category-list-container">';

			foreach( $categories_array as $category ) {
				echo '<a class="reports-category id-' . $category->cat_ID . '" href="http://temptraining.ru/category/' . $category->slug . '"/>' . $category->name . '</a>';
			};

			echo '</div><div style="clear: both;"></div>';

			if( !have_posts() ) {
				echo '<p>Записей не найдено!</p>';
			}
			/* Start the Loop */
			while ( have_posts() ) : the_post();

				//print_r( $posts );

			if (t==0) {
				    $t = get_the_modified_time('F jS, Y');
			}

				?>
					<article class="post type-post status-publish format-standard hentry">
						<header class="entry-header">
							<h2 class="reports-post"><?php echo '[' . date( 'd.m.y', strtotime( $post->post_date ) ) . '] ' . $post->post_title; ?></h2>
						</header>
						<div class="reports-post-miniature">
							<a href="<?php echo $post->guid; ?>" title="<?php echo $post->guid; ?>"><?php echo get_the_post_thumbnail( $post->ID, 'thumbnail' ); ?></a>
						</div>

<?php
    $author = 'temptraining';
    $title = 'category ' . $category->slug;
echo '<div class="hatom-extra" style="display:none;visibility:hidden;"><span class="entry-title">'.$title.'</span> was last modified: <span class="updated"> '.$t.'</span> by <span class="author vcard"><span class="fn">'.$author.'</span></span></div>' 
?>

						<div class="entry-content">
							<?php
								echo '<p>' . implode(' ', array_slice( explode( ' ', strip_tags( $post->post_content ) ), 0, 60 ) ) . ' <a href="' . $post->guid . '">далее...</a></p>';						
							?>
						</div>
					</article>
				<?php
			endwhile;

			twentytwelve_content_nav( 'nav-below' );
			?>
		</div><!-- #content -->
	</section><!-- #primary -->

<?php get_sidebar(); ?>
<?php get_footer(); ?>