<?php
/**
 * The template for displaying the footer.
 *
 * Contains footer content and the closing of the
 * #main and #page div elements.
 *
 * @package WordPress
 * @subpackage Twenty_Twelve
 * @since Twenty Twelve 1.0
 */
?>
	</div><!-- #main .wrapper -->
	<footer id="colophon" role="contentinfo">
		<div class="site-info">
			<div>
				© 2015 Центр подготовки спортсменов "Темп"
				<!--
				<br />
				<a href="<?php echo home_url() . '/?wpmd_action=nomobile'; ?>">Версия в полном разрешении</a>
				-->
				&nbsp;&nbsp;&nbsp;&nbsp;<a href="mailto:info@temptraining.ru"><strong>info@temptraining.ru</strong></a>&nbsp;&nbsp;&nbsp;&nbsp;<a target="_blank" href="http://www.facebook.com/temptraining"><img src="<?php echo get_template_directory_uri(); ?>/images/logo_fb.png" width="32" height="32" alt="Facebook logo"/></a>&nbsp;<a target="_blank" href="http://vk.com/temptraining"><img src="<?php echo get_template_directory_uri(); ?>/images/logo_vk.png" width="32" height="32" alt="ВКонтакте logo"/></a>&nbsp;<a target="_blank" href="http://twitter.com/temptraining"><img src="<?php echo get_template_directory_uri(); ?>/images/logo_twitter.png" width="32" height="32" alt="Twitter logo"/></a>&nbsp;<a target="_blank" href="http://plus.google.com/+TemptrainingRuTT"><img width="32" height="32" alt="Google Plus logo" src="<?php echo get_template_directory_uri(); ?>/images/logo_googleplus.png"/></a>&nbsp;<a target="_blank" href="http://www.youtube.com/user/temptrainingru"><img width="32" height="32" alt="YouTube logo" src="<?php echo get_template_directory_uri(); ?>/images/logo_youtube.png"/></a>
			</div>
		</div><!-- .site-info -->
	</footer><!-- #colophon -->
</div><!-- #page -->

<?php wp_footer(); ?>
</body>
</html>