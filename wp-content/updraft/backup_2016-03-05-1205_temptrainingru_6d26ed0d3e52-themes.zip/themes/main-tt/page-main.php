<?php
/**
 * The template for displaying all pages.
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site will use a
 * different template.
 *
 * @package WordPress
 * @subpackage Twenty_Twelve
 * @since Twenty Twelve 1.0
 
   Template Name: главная страница
 */

get_header(); ?>

	<div id="primary" class="site-content temp-page-no-h1">
		<div id="content" role="main">
			<div style="text-align: center; width: 790px; padding-top: 12px;"><button class="begin-training-button" onclick="window.location ='http://temptraining.ru/start/';"></button></div>
<!--			<div style="text-align: center; width: 790px; padding-top: 12px;"><button class="begin-training-button" onclick="window.location ='mailto:info@temptraining.ru';"></button></div> -->
			<div style="clear: both;"></div>
			<?php while ( have_posts() ) : the_post(); ?>
				<?php get_template_part( 'content', 'page' ); ?>
				<?php comments_template( '', true ); ?>
			<?php endwhile; // end of the loop. ?>
			<div class="frontpage-right-banner">
				<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
					<!-- Объявление на главной странице для десктоп-версии -->
					<ins class="adsbygoogle" style="display:inline-block;width:160px;height:600px" data-ad-client="ca-pub-7871590412442462" data-ad-slot="2172693635"></ins>
				<script>
					(adsbygoogle = window.adsbygoogle || []).push({});
				</script>
			</div>
		</div><!-- #content -->
	</div><!-- #primary -->

<?php get_sidebar(); ?>
<?php get_footer(); ?>