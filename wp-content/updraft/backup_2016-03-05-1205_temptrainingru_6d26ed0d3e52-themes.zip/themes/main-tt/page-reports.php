<?php
/**
 * The template for displaying all pages.
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site will use a
 * different template.
 *
 * @package WordPress
 * @subpackage Twenty_Twelve
 * @since Twenty Twelve 1.0

   Template Name: наши успехи
 */

get_header(); ?>

<section id="primary" class="site-content">
	<div id="content" role="main">

		<?php

			$args = array(
				'type'                     => 'post',
				'child_of'                 => 0,
				'parent'                   => '',
				'orderby'                  => 'name',
				'order'                    => 'DESC',
				'hide_empty'               => 0,
				'hierarchical'             => 1,
				'exclude'                  => '1',
				'include'                  => '',
				'number'                   => '',
				'taxonomy'                 => 'category',
				'pad_counts'               => false
			);
	
			$categories_array = get_categories( $args );
			

			echo '<div class="category-list-container">';

			foreach( $categories_array as $category ) {
				echo '<a class="reports-category id-' . $category->cat_ID . '" href="http://temptraining.ru/category/' . $category->slug . '"/>' . $category->name . '</a>';
			};

			echo '</div><div style="clear: both;"></div>';

			$args = array(
				'posts_per_page'   => 10,
				'offset'           => 0,
				'category'         => '',
				'orderby'          => 'post_date',
				'order'            => 'DESC',
				'include'          => '',
				'exclude'          => '',
				'meta_key'         => '',
				'meta_value'       => '',
				'post_type'        => 'post',
				'post_mime_type'   => '',
				'post_parent'      => '',
				'post_status'      => 'publish',
				'suppress_filters' => true );

			$posts_array = get_posts( $args );

			foreach( $posts_array as $post) {
				?>
					<article class="post type-post status-publish format-standard hentry">
						<header class="entry-header">
							<h2 class="reports-post"><?php echo '[' . date( 'd.m.y', strtotime( $post->post_date ) ) . '] ' . $post->post_title; ?></h2>
						</header>
						<div class="reports-post-miniature">
							<a href="<?php echo $post->guid; ?>" title="<?php echo $post->guid; ?>"><?php echo get_the_post_thumbnail( $post->ID, 'thumbnail' ); ?></a>
						</div>

<?php
    $t = get_the_modified_time('F jS, Y');
    $author = 'temptraining';
    $title = get_the_title();
echo '<div class="hatom-extra" style="display:none;visibility:hidden;"><span class="entry-title">'.$title.'</span> was last modified: <span class="updated"> '.$t.'</span> by <span class="author vcard"><span class="fn">'.$author.'</span></span></div>' 
?>
						<div class="entry-content">
							<?php
								echo '<p>' . implode(' ', array_slice( explode( ' ', strip_tags( $post->post_content ) ), 0, 60 ) ) . ' <a href="' . $post->guid . '">далее...</a></p>';						
							?>
						</div>
					</article>
				<?php
			}
		?>

<a href="http://temptraining.ru/reports-archive/"><< Предыдущие отчёты</a>

	</div><!-- #content -->
</section><!-- #primary -->

<?php get_sidebar(); ?>
<?php get_footer(); ?>
