<?php
/**
 * The template for displaying all pages.
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site will use a
 * different template.
 *
 * @package WordPress
 * @subpackage Twenty_Twelve
 * @since Twenty Twelve 1.0
 */

get_header(); ?>

	<div id="primary" class="site-content temp-page-no-h1">
		<div id="content" role="main">

			<?php while ( have_posts() ) : the_post(); ?>
				<?php get_template_part( 'content', 'page' ); ?>
				<?php comments_template( '', true ); ?>
			<?php endwhile; // end of the loop. ?>
<?php

switch (get_the_title()) {
	case 'Дневник спортивной активности TrainingPeaks':
	case 'Как похудеть? Диета? Спорт? Почему я не могу?':
	case 'Инвентарь для плавания и тренировок в бассейне':
	case 'Настройка посадки на велосипеде с помощью Bike Fast Fit':
	case 'Расширенная аналитика TrainingPeaks':
		echo "<script async src=\"//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js\"></script><ins class=\"adsbygoogle\" style=\"display:inline-block;width:728px;height:90px\" data-ad-client=\"ca-pub-7871590412442462\" data-ad-slot=\"2312830831\"></ins><script>(adsbygoogle = window.adsbygoogle || []).push({});</script>";
	break;
}

?>
		</div><!-- #content -->
	</div><!-- #primary -->

<?php get_sidebar(); ?>
<?php get_footer(); ?>