<?php
/**
 * The Template for displaying all single posts.
 *
 * @package WordPress
 * @subpackage Twenty_Twelve
 * @since Twenty Twelve 1.0
 */

get_header(); ?>

	<div id="primary" class="site-content">
		<div id="content" role="main">

			<?php

			$args = array(
				'type'                     => 'post',
				'child_of'                 => 0,
				'parent'                   => '',
				'orderby'                  => 'name',
				'order'                    => 'DESC',
				'hide_empty'               => 0,
				'hierarchical'             => 1,
				'exclude'                  => '1',
				'include'                  => '',
				'number'                   => '',
				'taxonomy'                 => 'category',
				'pad_counts'               => false
			);
	
			$categories_array = get_categories( $args );
			

			echo '<div class="category-list-container">';

			foreach( $categories_array as $category ) {
				echo '<a class="reports-category id-' . $category->cat_ID . '" href="http://temptraining.ru/category/' . $category->slug . '"/>' . $category->name . '</a>';
			};

			echo '</div><div style="clear: both;"></div>';
			?>

			<?php while ( have_posts() ) : the_post(); ?>

				<article class="post type-post status-publish format-standard hentry">
					<header class="entry-header">
						<h2 class="reports-post"><?php echo '[' . date( 'd.m.y', strtotime( $post->post_date ) ) . '] ' . $post->post_title; ?></h2>
					</header>

<?php
    $t = get_the_modified_time('F jS, Y');
    $author = 'temptraining';
    $title = get_the_title();
echo '<div class="hatom-extra" style="display:none;visibility:hidden;"><span class="entry-title">'.$title.'</span> was last modified: <span class="updated"> '.$t.'</span> by <span class="author vcard"><span class="fn">'.$author.'</span></span></div>' 
?>


					<div class="entry-content">
						<?php echo get_the_content(); ?>
					</div>
				</article>

<?php
	$jsps_networks = array( 'facebook', 'twitter', 'google', 'linkedin', 'vk' );
	/* show counters */
	$show_counters = 1;

	/* display buttons */
	juiz_sps( $jsps_networks, $show_counters );
?>

				<nav class="nav-single">
					<h3 class="assistive-text"><?php _e( 'Post navigation', 'twentytwelve' ); ?></h3>
					<span class="nav-previous"><?php previous_post_link( '%link', '<span class="meta-nav">' . _x( '&larr;', 'Previous post link', 'twentytwelve' ) . '</span> %title' ); ?></span>
					<span class="nav-next"><?php next_post_link( '%link', '%title <span class="meta-nav">' . _x( '&rarr;', 'Next post link', 'twentytwelve' ) . '</span>' ); ?></span>
				</nav><!-- .nav-single -->


			<?php endwhile; // end of the loop. ?>

		</div><!-- #content -->
	</div><!-- #primary -->

<?php get_sidebar(); ?>
<?php get_footer(); ?>