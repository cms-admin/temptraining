<?php
/**
 * The template for displaying Category pages.
 *
 * Used to display archive-type pages for posts in a category.
 *
 * Learn more: http://codex.wordpress.org/Template_Hierarchy
 *
 * @package WordPress
 * @subpackage Twenty_Twelve
 * @since Twenty Twelve 1.0
 */

get_header(); ?>

	<section id="primary" class="site-content">
		<div id="content" role="main">

		<?php

			$args = array(
				'type'                     => 'post',
				'child_of'                 => 0,
				'parent'                   => '',
				'orderby'                  => 'name',
				'order'                    => 'DESC',
				'hide_empty'               => 0,
				'hierarchical'             => 1,
				'exclude'                  => '1',
				'include'                  => '',
				'number'                   => '',
				'taxonomy'                 => 'category',
				'pad_counts'               => false
			);
	
			$categories_array = get_categories( $args );
			
			echo '<div class="category-list-container">';

			foreach( $categories_array as $category ) {
				echo '<a class="reports-category id-' . $category->cat_ID . '" href="http://m.temptraining.ru/category/' . $category->slug . '"/>' . $category->name . '</a>&nbsp;';
			};

			echo '</div><div style="clear: both;"></div>';

			if( !have_posts() ) {
				echo '<p style="text-indent: 12px; margin-top: 24px;">Записей не найдено!</p>';
			}
			/* Start the Loop */
			while ( have_posts() ) : the_post();

				//print_r( $posts );
				?>
					<article class="post type-post status-publish format-standard hentry">
						<header class="entry-header">
							<h2 class="reports-post"><?php echo '[' . date( 'd.m.y', strtotime( $post->post_date ) ) . '] ' . $post->post_title; ?></h2>
						</header>
						<div class="reports-post-miniature">
							<a href="http://m.temptraining.ru?p=<?php echo $post->ID; ?>" title=""><?php echo get_the_post_thumbnail( $post->ID, 'thumbnail' ); ?></a>
						</div>
						<div class="entry-content">
							<?php
								echo apply_filters( 'the_content', get_the_content( 'далее...' ) );		
							?>
						</div>
					</article>
				<?php
			endwhile;

			twentytwelve_content_nav( 'nav-below' );
			?>
		</div><!-- #content -->
	</section><!-- #primary -->

<?php get_sidebar(); ?>
<?php get_footer(); ?>