<?php
/**
 * The template for displaying the footer.
 *
 * Contains footer content and the closing of the
 * #main and #page div elements.
 *
 * @package WordPress
 * @subpackage Twenty_Twelve
 * @since Twenty Twelve 1.0
 */
?>
	</div><!-- #main .wrapper -->
	<footer id="colophon" role="contentinfo">
		<div class="site-info">
			<div>
				© 2015 Центр подготовки спортсменов "Темп".<br />
				<a href="<?php echo home_url() . '/?wpmd_action=nomobile'; ?>">Версия в полном разрешении</a>
			</div>
		</div><!-- .site-info -->
	</footer><!-- #colophon -->
</div><!-- #page -->

<?php wp_footer(); ?>
<?php
	if( isset( $_REQUEST['test-js']) ) {
		?>
			<script type="text/javascript">

if (document.body && document.body.offsetWidth) {
 winW = document.body.offsetWidth;
 winH = document.body.offsetHeight;
}
if (document.compatMode=='CSS1Compat' &&
    document.documentElement &&
    document.documentElement.offsetWidth ) {
 winW = document.documentElement.offsetWidth;
 winH = document.documentElement.offsetHeight;
}
if (window.innerWidth && window.innerHeight) {
 winW = window.innerWidth;
 winH = window.innerHeight;
}

var htmlW = $( 'html' ).width();

$( 'document' ).ready( function() {
	alert( winW + 'x' + winH + '\n' + htmlW);
});
			</script>
		<?php
	}
?>
</body>
</html>