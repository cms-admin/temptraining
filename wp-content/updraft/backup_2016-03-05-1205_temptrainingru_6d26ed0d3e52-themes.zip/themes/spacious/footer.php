<?php 
/**
 * Theme Footer Section for our theme.
 * 
 * Displays all of the footer section and closing of the #main div.
 *
 * @package ThemeGrill
 * @subpackage Spacious
 * @since Spacious 1.0
 */
?>

		</div><!-- .inner-wrap -->
	</div><!-- #main -->	
	<?php do_action( 'spacious_before_footer' ); ?>
		<footer id="colophon" class="clearfix">	
			<?php get_sidebar( 'footer' ); ?>	
			<div class="footer-socket-wrapper clearfix">
				<div class="inner-wrap">
					<div class="footer-socket-area">
						<?php //do_action( 'spacious_footer_copyright' ); ?>
						
						<div class="copy-left">
				© <?php echo date('Y'); ?> Центр подготовки спортсменов "Темп"
				</div>
				<div class="copy-right">
				<a target="_blank" href="https://www.facebook.com/temptraining"><img src="https://temptraining.ru/wp-content/themes/main-tt/images/logo_fb.png" alt="Facebook" width="32" height="32"></a>&nbsp;&nbsp;<a target="_blank" href="https://vk.com/temptraining"><img src="https://temptraining.ru/wp-content/themes/main-tt/images/logo_vk.png" alt="ВКонтакте" width="32" height="32"></a>&nbsp;&nbsp;<a target="_blank" href="https://twitter.com/temptraining"><img src="https://temptraining.ru/wp-content/themes/main-tt/images/logo_twitter.png" alt="Twitter" width="32" height="32"></a>&nbsp;&nbsp;<a target="_blank" href="https://plus.google.com/+TemptrainingRuTT"><img alt="Google Plus" src="https://temptraining.ru/wp-content/themes/main-tt/images/logo_googleplus.png" width="32" height="32"></a>&nbsp;&nbsp;<a target="_blank" href="https://www.youtube.com/user/temptrainingru"><img alt="YouTube" src="https://temptraining.ru/wp-content/themes/main-tt/images/logo_youtube.png" width="32" height="32"></a>
				</div>

						<div class="fbackfeed"><a href="<?php echo get_site_url(); ?>/feedback/">Написать директору</a></div>
						<nav class="small-menu clearfix">
							<?php
								if ( has_nav_menu( 'footer' ) ) {									
										wp_nav_menu( array( 'theme_location' => 'footer',
																 'depth'           => -1
																 ) );
								}
							?>
		    			</nav>
					</div>
				</div>
			</div>			
		</footer>
		<a href="#masthead" id="scroll-up"></a>	
	</div><!-- #page -->
	<?php wp_footer(); ?>
</body>
</html>