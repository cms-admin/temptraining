<?php
/**
 * Template Name: Business Template
 *
 * Displays the Business Template of the theme.
 *
 * @package ThemeGrill
 * @subpackage Spacious
 * @since Spacious 1.0
 */
?>

<?php get_header(); ?>

<div id="content" class="clearfix">
	<section id="spacious_service_widget-3" class="widget widget_service_block nomargin_top nomargin_bottom clearfix">	
	<div class="tg-two-third">
	<?php 
	if( is_active_sidebar( 'spacious_business_page_top_section_sidebar' ) ) {
		// Calling the business page top section sidebar if it exists.
		if ( !dynamic_sidebar( 'spacious_business_page_top_section_sidebar' ) ):
		endif;
	}
	?>
	<section id="spacious_service_widget-2" class="widget widget_service_block nomargin_top nomargin_bottom clearfix">	
	<?php
   	if( spacious_options( 'spacious_activate_slider', '0' ) == '1' ) {
   		if( spacious_options( 'spacious_blog_slider', '0' ) == '0' ) {
   			if( is_home() || is_front_page() ) {
   				spacious_featured_image_slider();
			}
   		} else {
   			if( is_front_page() ) {
   				spacious_featured_image_slider();
   			}
   		}
   	}

		
		?>
	<?php the_content(); ?>
	
</section>



</div>
<div class="tg-one-two-third">
<!-- Вывод успехов -->
	<section id="spacious_recent_work_widget-2" class="widget widget_recent_work clearfix">
	<?php

			

			$args = array(
				'posts_per_page'   => 3,
				'offset'           => 0,
				'category'         => '',
				'orderby'          => 'post_date',
				'order'            => 'DESC',
				'include'          => '',
				'exclude'          => '',
				'meta_key'         => '',
				'meta_value'       => '',
				'post_type'        => 'post',
				'post_mime_type'   => '',
				'post_parent'      => '',
				'post_status'      => 'publish',
				'suppress_filters' => true );

			$posts_array = get_posts( $args );

			foreach( $posts_array as $key=>$post) {
				?>
					<div class="lastnews clearfix">
						
						<div class="reports-post-miniature">
							<a href="<?php echo get_permalink($post->ID); ?>" title="<?php echo get_permalink($post->ID); ?>"><?php //echo get_the_post_thumbnail( $post->ID, 'thumbnail' ); 
								$attr = array(
									'class'	=> 'attachment-featured-blog-medium size-featured-blog-medium wp-post-image',								'sizes' => '(max-width: 150px) 100vw, 270px'
									);
								$thumbnail = get_the_post_thumbnail( $post->ID, 'thumbnail', $attr );

								echo $thumbnail;
							?></a>
						</div>

						<time class="rpwe-time published"><?php echo date( 'o-m-d', strtotime( $post->post_date ) ) ."</time><h6><a href=\"" . get_permalink($post->ID) . "\">". $post->post_title; ?></a></h6>

<?php
    $t = get_the_modified_time('F jS, Y');
    $author = 'temptraining';
    $title = get_the_title();
echo '<div class="hatom-extra" style="display:none;visibility:hidden;"><span class="entry-title">'.$title.'</span> was last modified: <span class="updated"> '.$t.'</span> by <span class="author vcard"><span class="fn">'.$author.'</span></span></div>' 
?>
						<div class="entry-content">
							<?php
								echo '<p>' . implode(' ', array_slice( explode( ' ', strip_tags( $post->post_content ) ), 0, 30 ) ) . '...<br/> <a href="' . get_permalink($post->ID) . '">Читать далее →</a></p>';						
							?>
						</div>
					</div>
				<?php
			}
		?>
		</section>
		<!-- / Вывод успехов -->



</div>
	</section>
	
	<?php 
	/*if( is_active_sidebar( 'spacious_business_page_top_section_sidebar' ) ) {
		// Calling the business page top section sidebar if it exists.
		if ( !dynamic_sidebar( 'spacious_business_page_top_section_sidebar' ) ):
		endif;
	}*/

	if( is_active_sidebar( 'spacious_business_page_middle_section_left_half_sidebar' ) || is_active_sidebar( 'spacious_business_page_middle_section_right_half_sidebar' )) {
	?>
	<!-- <div class="clearfix"> -->
		<div class="tg-one-half">
			<?php
			// Calling the business page middle section left half sidebar if it exists.
			if ( !dynamic_sidebar( 'spacious_business_page_middle_section_left_half_sidebar' ) ):
			endif;
			?>
		</div>
		<div class="tg-one-half tg-one-half-last">
			<?php
			// Calling the business page middle section right half sidebar if it exists.
			if ( !dynamic_sidebar( 'spacious_business_page_middle_section_right_half_sidebar' ) ):
			endif;
			?>
		</div>
	<div class="clearfix"></div>
	<?php
	}/*

	if( is_active_sidebar( 'spacious_business_page_bottom_section_sidebar' ) ) {
		// Calling the business page bottom section sidebar if it exists.
		if ( !dynamic_sidebar( 'spacious_business_page_bottom_section_sidebar' ) ):
		endif;
	}*/
	?>

	</div>
	

<?php get_footer(); ?>