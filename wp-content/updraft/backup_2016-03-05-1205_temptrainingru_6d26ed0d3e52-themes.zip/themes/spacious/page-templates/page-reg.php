<?php
/**
 * The template for displaying all pages.
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site will use a
 * different template.
 *
 * @package WordPress
 * @subpackage Twenty_Twelve
 * @since Twenty Twelve 1.0

   Template Name: заявка на регистрацию
 */

$toEcho = '';

if( ( isset( $_REQUEST['phone'] ) ) || ( isset( $_REQUEST['email'] ) )  ) {
	if( ( $_REQUEST['phone'] != '') || ( $_REQUEST['email'] != '' ) ) {

		$clientName = htmlspecialchars( $_REQUEST['client-name'], ENT_QUOTES);
		$clientPhone = htmlspecialchars( $_REQUEST['phone'], ENT_QUOTES);
		$clientEmail = htmlspecialchars( $_REQUEST['email'], ENT_QUOTES);
		switch ( $_REQUEST['sport'] ) {
			case '1':
				$clientSport = 'Триатлон';
				switch ( $_REQUEST['triathlon'] ) {
					case '1':
						$clientPlan = 'Развивающая';
						break;
					case '2':
						$clientPlan = 'Подводящая';
						break;
				}
				break;
			case '2':
				$clientSport = 'Бег';
				break;
			case '3':
				$clientSport = 'Плавание';
				switch ( $_REQUEST['swimming'] ) {
					case '1':
						$clientPlan = 'Начинающий & Спринт';
						break;
					case '2':
						$clientPlan = 'Стайер & Open Water';
						break;
				}
				break;
		}
		$clientQuestion = htmlspecialchars( $_REQUEST['question'], ENT_QUOTES);

		$message = 'Ваш запрос на тренировки нами получен и в ближайшее время мы с Вами свяжемся!

От: ' . $clientName . '
Телефон: ' . $clientPhone . '
Email: ' . $clientEmail . '
Спорт: ' . $clientSport . '
Программа: ' . $clientPlan . '
Комментарий: ' . $clientQuestion;

		mail_utf8( 'kalinin@temptraining.ru', 'Запрос на регистрацию', $message );

		if ( ( isset( $clientEmail ) ) && ( filter_var( $clientEmail, FILTER_VALIDATE_EMAIL ) ) ) {
			mail_utf8( $clientEmail, 'Запрос на регистрацию', $message );
		}

		$toEcho = '<p>Мы получили Ваш запрос. В ближайшее время тренер с Вами свяжется.</p>';
	}
}

get_header(); ?>

	<div id="primary" class="site-content">
		<div id="content" role="main">
			<article id="" class="page type-page status-publish hentry">
				<header class="entry-header">
					<h1 class="entry-title"></h1>
				</header>
<?php
	if( $toEcho == '' ) {
?>
			
			<p><strong>Вы хотите тренироваться? Как с Вами связаться?</strong></p>
			<br />
			<form class="pre-reg-form" method="post">
							<p>Как к Вам обращаться?</p>							<input type="text" name="client-name" />							<p>Телефон:</p>							<input type="text" name="phone" />							<p>Email:</p>							<input type="text" name="email" />							<p>Чем вы хотите заниматься?</p>							<input type="radio" onclick="hideDivs(0)"  name="sport" value="0" checked />&nbsp;Не знаю<br />							<input onclick="hideDivs(3)"  type="radio" name="sport" value="3" />&nbsp;<span title="Плавание — вид спорта в котором спортсмену приходится соревноваться в непривычной для него среде, которая в отличии от воздуха имеет другие плотноть и свойства. Наши тренера поспособствуют достижению Ваших целей, а так же научат Вас: правильному «общению» с водой, как ее чувствать, для того, что бы использовать ее свойства на благо Вам и Вашему результату; преодолевать необходимую Вам дистанцию с минимальными потерями сил и времени; оптимизируют технику исходя из Ваших антропометрических и физических данных." >Плавание&nbsp;</span><br />							<div class="i-choose-swimming">								<p>Выберите программу:<br/>								<input type="radio" name="swimming" value="0" checked />&nbsp;Не знаю<br />								<input type="radio" name="swimming" onclick="hideDivs(1);" value="1" />&nbsp;<span title="1000 руб./неделя, минимум 4 недели. Программа разработана для новичков и людей склонных к коротким дистанциям желающим быть лучшими на дистанциях от 50 до 200 метров. Тренировки включают в себя специальные  упражнения  на развитие плавучести, умение держаться на воде для новичков, а так же силы, скорости и скоростной выносливости для людей желающих плавать быстро. Присутствие тренера для новичков обязательно." >Начинающий & Спринт&nbsp;</span><br />
								<input type="radio" name="swimming" value="2" />&nbsp;<span title="1000 руб./неделя, минимум 4 недели. Программа разработана для уверенных пловцов желающих принимать участие в заплывах на длинные дистанции в бассейне и открытой воде, а так же для триатлетов,  которые  хотят  выплывать в голове группы. Тренировки включают специальные упражнения повышающие  аэробные возможности организма, упражнения направленые на  умение ориентироваться в открытом водоеме." >Стайер & Open Water&nbsp;</span></p>
							</div>							<input type="radio" onclick="hideDivs(1)"  name="sport" value="1" />&nbsp;<span title="Триатлон — относительно молодой вид спорта, появившийся в 1974 году и включающий в себя непрерывное прохождение трёх этапов состязания: плавания, велогонки и бега. Предлагаем Вам занятия по двум нашим программам подготовки к триатлону, позволяющие успешно выступать на соревнованиях любого формата от 750м/20км/5км спринта до классической 3,8км/180км/42,2км.">Триатлон&nbsp;</span><br />														<div class="i-choose-triathlon">
								<p>Выберите программу:<br />
								<input type="radio" name="triathlon" value="0" checked  />&nbsp;Не знаю<br />
								<input type="radio" name="triathlon" value="1" />&nbsp;<span title="1500 руб./неделя, минимум 4 недели. Оптимально подходит для развития и поддержки уровня Вашей физической формы в межсезонье или при отсутствии чётких планов участия в соревнованиях. Тем самым, когда Вы примите решение о переходе к нашей Подводящей программе, Ваше тело будет полностью готово. Так же данная программа идеальна во время продолжительного разрыва между ранним и поздним стартом во время одного сезона." >Развивающая&nbsp;</span><br />
								<input type="radio" name="triathlon" value="2" />&nbsp;<span title="1500 руб./неделя, минимум 6 недель. Программа специально создана для подготовки Вас к главному старту. Нагрузка планируется в зависимости от потребностей и уровня подготовки на основании Ваших данных. Занятия будут расписаны на три основные фазы: базовая подводка, скоростные и специальные тренировки и предстартовая подготовка. Длительность программы планируется от даты начала тренировок и до непосредственной даты Вашего соревнования." >Подводящая&nbsp;</span></p>
							</div>
							<input type="radio" name="sport" onclick="hideDivs(2)" value="2" />&nbsp;Бег<br/><br/>
				<p>Расскажите о себе.</p>
				<textarea rows="5" cols="43" name="question"></textarea>				<input id="start-submit" type="submit" class="submit" value="Отправить" />			</form>

			<script type="text/javascript">
				/*$('#sport').click( function() {  alert( this.id + '  ' + this.value ); });*/

				function hideDivs( radioValue ) {										 //alert( radioValue );
					if ( radioValue == '1' ) {
						$( '.i-choose-swimming' ).hide( 500 );
						$( '.i-choose-triathlon' ).show( 500 );
					}
					if ( radioValue == '3' ) {
						$( '.i-choose-swimming' ).show( 500 );
						$( '.i-choose-triathlon' ).hide( 500 );
					}
					if( ( radioValue != '1' ) && ( radioValue != '3' ) ) {
						$( '.i-choose-swimming' ).hide( 500 );
						$( '.i-choose-triathlon' ).hide( 500 );
					}
				}

				$( '.pre-reg-form' ).submit( function( event ) {
					if ( !validateForm() ) {
						event.preventDefault();
					}
				})

				function validateForm() {
					if ( ( $( '[name="phone"]' ).val() != '' ) || ( $( '[name="email"]' ).val() != '') ) {
						return true;
					}
					else {
						alert( 'Пожалуйста заполните хотя бы один из способов связи с Вами: телефон или е-майл. В противном случае мы не сможем Вам ответить!' ); 
						return false;
					}
				}
			</script>
<?php
}
else {
	echo $toEcho;
	?>
		<script type="text/javascript">
			setTimeout( function() { window.location.href = 'https://temptraining.ru/'; }, 10000 );
		</script>
	<?php
}
?>
			</article>
		</div><!-- #content -->
	</div><!-- #primary -->

<?php get_sidebar(); ?>
<?php get_footer(); ?>