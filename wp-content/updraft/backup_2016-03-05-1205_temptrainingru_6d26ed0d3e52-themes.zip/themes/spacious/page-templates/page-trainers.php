<?php
/*
   Template Name: тренеры

 */



get_header(); ?>



<section id="primary" class="site-content">

	<div id="content" role="main">

	<div class="temp-trainer-div">
<a href="https://temptraining.ru/wp-content/uploads/2015/10/Ростягаев.jpeg"><img src="https://temptraining.ru/wp-content/uploads/2015/10/Ростягаев-225x300.jpeg" alt="Тренер по триатлону Дмитрий Ростягаев" width="225" height="300" class="alignnone size-medium wp-image-1679" /></a>
<strong>Ростягаев Дмитрий</strong>: МСМК по триатлону, КМС по легкой атлетике, КМС по плаванию, член сборной России по триатлону, победитель этапа мировой серии на длинной дистанции 2011 года, 5 место на чемпионате Европы Ironman 70.3 Висбаден 2011. Образование: высшее ЯГПУ им . Ушинского. Специализация: триатлон.<?php echo coachreviews('ростягаев'); ?></div>

<div class="temp-trainer-div">
<a href="https://temptraining.ru/wp-content/uploads/2015/10/Задорожный.jpeg"><img src="https://temptraining.ru/wp-content/uploads/2015/10/Задорожный-217x300.jpeg" alt="Тренер по бегу Задорожный Андрей" width="217" height="300" class="alignnone size-medium wp-image-1672" /></a>
<strong>Задорожный Андрей</strong>: МСМК по легкой атлетике, 11 кратный чемпион России, 3 место на чемпионате Европы 1998, финалист чемпионата мира 2003. Образование: высшее ЯГПУ им . Ушинского. Специализация: легкая атлетика.<?php echo coachreviews('задорожный'); ?></div>

<div class="temp-trainer-div">
<a href="https://temptraining.ru/wp-content/uploads/2015/10/Хабаров.jpeg"><img src="https://temptraining.ru/wp-content/uploads/2015/10/Хабаров-225x300.jpeg" alt="Тренер по триатлону Хабаров Евгений" width="225" height="300" class="alignnone size-medium wp-image-1681" /></a>
<strong>Хабаров Евгений</strong>: МС по триатлону. Призер Чемпионата ЦФО по плаванию. Специализация: триатлон.<?php echo coachreviews('хабаров'); ?>
</div>

<div class="temp-trainer-div">
<a href="https://temptraining.ru/wp-content/uploads/2015/10/Комаров.jpeg"><img src="https://temptraining.ru/wp-content/uploads/2015/10/Комаров-221x300.jpeg" alt="Тренер по триатлону Комаров Александр" width="221" height="300" class="alignnone size-medium wp-image-1677" /></a>
<strong>Комаров Александр</strong>: МС по морскому многоборью (плавание, бег, стрельба, парус, гребля), КМС по триатлону. Чемпион России 2011 года по морскому многоборью. Образование высшее (ЯГПУ им. Ушинского). Тренер высшей категории по плаванию. Специализация: плавание, триатлон<?php echo coachreviews('комаров'); ?>
</div>

<div class="temp-trainer-div">
<a href="https://temptraining.ru/wp-content/uploads/2015/10/Покровский.jpeg"><img src="https://temptraining.ru/wp-content/uploads/2015/10/Покровский-224x300.jpeg" alt="Тренер по триатлону Покровский Андрей" width="224" height="300" class="alignnone size-medium wp-image-1678" /></a>
<strong>Покровский Андрей</strong>: МС по триатлону, КМС по плаванию. Образование: Высшее ЯГПУ им. К.Д. Ушинского факультет физической культуры дополнительная специальность "Спортивная подготовка". С 2008 года тренер-преподаватель по триатлону в СДЮСШОР-7 г. Ярославль. С 2010 года персональный тренер по плаванию. Специализация: плавание, триатлон.
<?php echo coachreviews('покровский'); ?>
</div>

<div class="temp-trainer-div">
<a href="https://temptraining.ru/wp-content/uploads/2015/10/Калашников.jpeg"><img src="https://temptraining.ru/wp-content/uploads/2015/10/Калашников-225x300.jpeg" alt="Тренер по триатлону Калашников Иван" width="225" height="300" class="alignnone size-medium wp-image-1675" /></a>
<strong>Калашников Иван</strong>: МС по триатлону. 6-ое место на Чемпионате Европы 2013, Чемпион России на длинной дистанции 2015 года.
Победитель общего зачета кубка России 2014, 2-ое место 2015 года. Образование:  Тренер- преподаватель ( УОР г. Щелково). Специализация: триатлон.
<?php echo coachreviews('калашников'); ?>
</div>

<div class="temp-trainer-div">
<a href="https://temptraining.ru/wp-content/uploads/2015/10/Бурова.jpeg"><img src="https://temptraining.ru/wp-content/uploads/2015/10/Бурова-225x300.jpeg" alt="Тренер по триатлону Калашникова (Бурова) Анна" width="225" height="300" class="alignnone size-medium wp-image-1670" /></a>
<strong>Калашникова (Бурова) Анна</strong>: МС по триатлону. Чемпионка России по триатлону (спринт) 2010, 2014. Бронзовый призер чемпионатов России (олимпийская дистанция) 2012, 2013. Чемпионка Европы до 23 лет (эстафета) 2010. Образование: ФГОУ СПО "Государственное среднее профессиональное училище олимпийского резерва" с квалификацией педагог по Физической культуре и спорту 2010. Специализация: триатлон.<?php echo coachreviews('калашникова'); ?>
</div>

<div class="temp-trainer-div">
<a href="https://temptraining.ru/wp-content/uploads/2015/10/Тимохин.jpeg"><img src="https://temptraining.ru/wp-content/uploads/2015/10/Тимохин-225x300.jpeg" alt="Тренер по триатлону Тимохин Юрий" width="225" height="300" class="alignnone size-medium wp-image-1680" /></a>
<strong>Тимохин Юрий</strong>: КМС по плаванию, КМС по триатлону, КМС по морскому многоборью. Призер спартакиады учащихся ЦФО и ПФО по плаванию. Образование: высшее педагогическое Ярославский государственный педагогический университет. Специализация: триатлон.<?php echo coachreviews('тимохин'); ?>
</div>

<div class="temp-trainer-div">
<a href="https://temptraining.ru/wp-content/uploads/2015/10/Задорожная.jpeg"><img src="https://temptraining.ru/wp-content/uploads/2015/10/Задорожная-225x300.jpeg" alt="Тренер по ОФП Задорожная Ольга" width="225" height="300" class="alignnone size-medium wp-image-1671" /></a>
<strong>Задорожная Ольга</strong>: Образование: высшее ЯГПУ им . Ушинского. Специализация: лёгкая атлетика, фитнес.<?php echo coachreviews('задорожная'); ?>
</div>

<div class="temp-trainer-div">
<a href="https://temptraining.ru/wp-content/uploads/2015/10/Зыкова.jpeg"><img src="https://temptraining.ru/wp-content/uploads/2015/10/Зыкова-225x300.jpeg" alt="Тренер по триатлону Зыкова Наталья" width="225" height="300" class="alignnone size-medium wp-image-1673" /></a>
<strong>Зыкова Наталья</strong>: МС по триатлону. Победительница Финала Кубка России по триатлону 2010. Судья всероссийской и международной категорий. Тренер СДЮСШОР-7 г. Ярославль по триатлону с 2012 года. Специализация: триатлон.<?php echo coachreviews('зыкова'); ?>
</div>

<div class="temp-trainer-div">
<a href="https://temptraining.ru/wp-content/uploads/2016/02/Зеленов.jpg" rel="attachment wp-att-2349"><img src="https://temptraining.ru/wp-content/uploads/2016/02/Зеленов-217x300.jpg" alt="Тренер по триатлону Сергей Зеленов" width="217" height="300" class="alignnone size-medium wp-image-2349" /></a>
<strong>Зеленов Сергей</strong>: МС по триатлону, КМС по плаванию. Призер и победитель кубков России. Тренер в СДЮШОР-7 г. Ярославль с 2008 по 2010. Выступал во французской про команде D1 с 2010 по 2012 года. Образование - высшее педагогическое ФФК. Специализация: триатлон.<?php echo coachreviews('зеленов'); ?>
</div>

<div class="temp-trainer-div">
<a href="https://temptraining.ru/wp-content/uploads/2015/10/Ильин.jpeg"><img src="https://temptraining.ru/wp-content/uploads/2015/10/Ильин-225x300.jpeg" alt="Тренер по триатлону Дмитрий Ильин" width="225" height="300" class="alignnone size-medium wp-image-1674" /></a>
<strong>Ильин Дмитрий</strong>: КМС по лыжным гонкам, КМС по триатлону. Финишер 6 х Half-Ironman и Ironman Kalmar Sweden 2014. Специализация: триатлон.<?php echo coachreviews('ильин'); ?>
</div>

<div class="temp-trainer-div">
<a href="https://temptraining.ru/wp-content/uploads/2015/10/Калинин.jpeg"><img src="https://temptraining.ru/wp-content/uploads/2015/10/Калинин-225x300.jpeg" alt="Тренер по триатлону Калинин Алексей" width="225" height="300" class="alignnone size-medium wp-image-1676" /></a>
<strong>Калинин Алексей</strong>: Вдохновитель проекта. Финишер Ironman Austria 2014. Специализация: триатлон.<?php echo coachreviews('калинин'); ?>
</div>

		



	</div><!-- #content -->

</section><!-- #primary -->



<?php get_sidebar(); ?>

<?php get_footer(); ?>

