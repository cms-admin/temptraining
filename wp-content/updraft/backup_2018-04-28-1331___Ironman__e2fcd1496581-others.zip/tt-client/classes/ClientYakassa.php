<?php

namespace TTClient;

use TTClient\Client;
use YandexCheckout\Client as KassaClient;

class ClientYakassa
{
  protected $root_dir;
  protected $wpdb;
  protected $payment_type = 'yandex_money';
  protected $kassa;
  protected $options;

  private static $instance;

  public function __construct($site_dir){
    $this->root_dir = ( !defined('ABSPATH') ) ? $site_dir : ABSPATH;

    require_once (__dir__ . '/Spyc.php');
    require_once ($this->root_dir . 'wp-config.php');
    require_once ($this->root_dir . 'wp-includes/wp-db.php');
    require_once ($this->root_dir . 'wp-includes/pluggable.php');
    require_once ($this->root_dir . 'wp-includes/capabilities.php');
    require_once ($this->root_dir . 'wp-includes/class-wp-query.php');
    require_once (TT_CLIENT_DIR . 'classes/lib/autoload.php');

    global $wpdb;
    $this->wpdb = $wpdb;

    $this->options = Client::getInstance()->getPluginOptions();
    $this->kassa = new KassaClient();
    $this->kassa->setAuth($this->options['yakassa_shopid'], $this->options['yakassa_secret_key']);
  }

  /**
   * @return ClientYakassa
   */
  public static function getInstance($site_dir = false) {
    if (null === self::$instance)
      return self::$instance = new self($site_dir);
    else
      return self::$instance;
  }

  /**
   * Проверяет соответствие суммы оплаты, периода и стоимости тарифа
   *
   * @param array $post
   * @return void
   */
  public function checkFormTariff($post)
  {
    $prefix = $this->wpdb->prefix;
    $client_id_name = $post['client_id_name'];

    $query = "SELECT * "
    ."FROM {$prefix}clients "
    ."WHERE client_id_name = '{$client_id_name}' "
    ."AND can_pay = '1'";

    $client = $this->wpdb->get_row($query);
    
    return ($client) ? $client : false;
  }

  /**
   * Формирует платеж
   *
   * @param integer $sum  Сумма оплаты.
   * @param object $client
   * @return void
   */
  public function createPayment($sum, $client, $type = 'tariff')
  {
    $options = Client::getInstance()->getPluginOptions();
    $kassa = new KassaClient();

    $kassa->setAuth($options['yakassa_shopid'], $options['yakassa_secret_key']);

    switch ($type){
      case 'tariff':
        $paymentParams = array(
          'amount' => array(
            'value' => number_format($sum, 2, '.', ''),
            'currency' => 'RUB',
          ),
          'receipt' => array( // Данные для формирования чека в онлайн-кассе (для соблюдения 54-ФЗ)
            'items' => array(
              array(
                'description' => $client->client_tarif_name,                // *Название товара
                'quantity'  => intval($sum) / intval($client->tarif_cost),  // *Количество
                'amount'  => array(                                         // *Сумма с указанием валюты
                  'value' => number_format($sum, 2, '.', ''),               // *Сумма
                  'currency'  => 'RUB',                                     // *Код валюты
                ),
                'vat_code'  => 1,                                           // *Ставка НДС, число от 1 до 6
              ),
            ),
            'tax_system_code' => 1,
            'email' => $client->client_id_name
          ),
          'payment_method_data' => array(
            'type' => $this->payment_type,
          ),
          'confirmation' => array(
            'type' => 'redirect',
            'return_url' => home_url('client')
          ),
        );
        break;
    }

    try {
      $response = $kassa->createPayment($paymentParams, uniqid('', true));
    } catch (Exception $exc) {
      return array(
        'success' => false,
        'error'   => $exc->getMessage(),
      );
    }

    if ($response['status'] == 'pending'){
      # Добавляет запись о заказе в базу данных заказов

      # Перенаправляет клиента на страницу оплаты
      return array(
        'success' => true,
        'redirect'  => $response['confirmation']['confirmation_url'],
      );
    }
  }

  /**
   * Проверяет незавершенные заказы
   *
   * @param [type] $client_id
   * @param [type] $order_id
   * @return void
   */
  public function checkPayment($client_id, $payment)
  {
    $payment = $this->kassa->getPaymentInfo($payment->order_id);

    var_dump($payment);
  }


  public function checkNotification($object)
  {
    
  }
}